package br.com.listaexerciciosbasicos.Exercicios;

import java.util.Scanner;

public class Exercicio05 {

	public static void main(String[] args) {

		Scanner leia = new Scanner(System.in);
		double salMinimo , seuSalario;
		double qtdSalariosMinimos;
		
		System.out.println("Digite o valor do salario minimo: ");
		salMinimo = leia.nextDouble();
		System.out.println("Digite o valor do seu salario: ");
		seuSalario = leia.nextDouble();
		
		qtdSalariosMinimos = seuSalario / salMinimo;
		
		if (seuSalario > salMinimo) {
			System.out.println((int) qtdSalariosMinimos + " SM = Sobou R$" + ( seuSalario - salMinimo) % salMinimo  );
		} else {
			System.out.println("Faltam R$" + ((seuSalario - salMinimo) * -1) + " reais para você alcançar o salário mínimo");
		}
		
		
		
		

	}

}
