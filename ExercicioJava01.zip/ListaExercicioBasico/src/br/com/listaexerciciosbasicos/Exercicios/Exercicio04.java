package br.com.listaexerciciosbasicos.Exercicios;

import java.util.Scanner;

public class Exercicio04 {

	public static void main(String[] args) {

		Scanner leia = new Scanner(System.in);

		int num, antecessor, sucessor;
		
		System.out.println("Informe um número: ");
		num = leia.nextInt();
		
		antecessor = num - 1;
		sucessor = num + 1;
		
		System.out.println("O numero é " + num + " antecessor é " + antecessor);
		System.out.println("O numero é " + num + " sucessor é " + sucessor);
		
		
	}

}
