package br.com.listaexerciciosbasicos.Exercicios;

import java.util.Scanner;

public class Exercicio03 {

	public static void main(String[] args) {

		Scanner leia = new Scanner(System.in);
		double salario, reajusteSal;
		
		
		System.out.println("Digite o seu saldo: ");
		salario = leia.nextDouble();
		
		
		reajusteSal = salario + (salario*0.01);

		System.out.println("O saldo com reajuste é: " + reajusteSal);
		
	}

}
