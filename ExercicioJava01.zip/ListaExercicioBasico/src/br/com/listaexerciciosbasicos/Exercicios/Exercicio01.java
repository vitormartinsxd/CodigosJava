package br.com.listaexerciciosbasicos.Exercicios;

import java.util.Scanner;

public class Exercicio01 {

	public static void main(String[] args) {
		
		Scanner leia = new Scanner(System.in);
		int  idadeAnos, idadeMeses, idadeDias=0, resultadoDias=0;
		int idade;
		
		System.out.println("Digite a sua idade em Anos: ");
		idadeAnos = leia.nextInt();
		
		
		System.out.println("Digite a sua idade em Meses: ");
		idadeMeses = leia.nextInt();
		
		System.out.println("Digite a sua idade em Dias: ");
		idade = leia.nextInt();
		
		idadeDias = ((idadeAnos*365) + (idadeMeses*30) + (idade));
		
		System.out.println("A sua idade em anos é: "+ idadeAnos);
		System.out.println("A sua idade em meses é: " + idadeMeses);
		System.out.println("A sua idade em dia é: " + idadeDias);
		
				
		
		
		leia.close();
		
	}

}
