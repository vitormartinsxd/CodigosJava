package br.com.listaexerciciosbasicos.Exercicios;

public class Exercicio02 {

	public static void main(String[] args) {
		double mediaA01, mediaA02, somaMedias, mediaGeral;
		int n1 = 8, n2 = 9, n3 = 7, n4 = 4, n5 = 5, n6 = 6;
		
		mediaA01 = (n1 + n2 + n3)/3;
		mediaA02 = (n4 + n5 + n6)/3;
		
		somaMedias = mediaA01 + mediaA02;
		
		mediaGeral = (mediaA01 + mediaA02)/2;
		
		System.out.println("A media aritmética do aluno 01 é : " + mediaA01);
		System.out.println("A media aritmética do aluno 02 é : " + mediaA02);
		System.out.println("A soma das médias é: " + somaMedias);
		System.out.println("A media geral é: " + mediaGeral);
		
		
	}

}
