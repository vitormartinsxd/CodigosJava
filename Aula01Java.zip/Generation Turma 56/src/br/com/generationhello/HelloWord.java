package br.com.generationhello;

import java.util.Scanner;
public class HelloWord {

	public static void main(String[] args) {

		Scanner entrada = new Scanner(System.in);
		Scanner entrada2 = new Scanner(System.in);


		double numero1, numero2, numero3;
		double media;
		char opcao;

		System.out.println("Digite o primeiro numero: ");
		numero1 = entrada.nextDouble();
		System.out.println("Digite o segundo numero: ");
		numero2 = entrada.nextDouble();
		System.out.println("Digite o terceiro numero: ");
		numero3 = entrada.nextDouble();

		System.out.println("Dgite 'A' para media Aritmetica e 'P' para ponderada: ");
		opcao = entrada2.nextLine().charAt(0);

		media = calcularMedia(numero1,numero2,numero3,opcao);

		System.out.println("Media das notas: " + media);


	}
	public static double calcularMedia(double n1, double n2, double n3, char op){

		double media;

		if (op != 'A' && op != 'P'){
			System.out.println("Operador invalido");
			media = -1;
		}else{
			if (op== 'A'){    
				media = (n1 + n2 + n3)/3;
			}    
			else {
				media = ((n1*5) + (n2*3)+ (n3*2))/10;
			}
		}

		return media;

	}

}
