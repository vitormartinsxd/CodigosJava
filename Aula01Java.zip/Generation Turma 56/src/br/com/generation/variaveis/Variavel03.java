package br.com.generation.variaveis;

import java.util.Scanner;
public class Variavel03 {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		
		int var1;
		double var2;
		
		System.out.println("Digite o primeiro numero: ");
		var1 = entrada.nextInt();
		System.out.println("Digite o segundo numero: ");
		var2 = entrada.nextDouble();
		
		System.out.println("O valor original da 1º variavel: " +  var1);
		System.out.println("O valor original da 2º variavel: " +  var2);
		
		var1 = var1/4;
		var2 = var2/4;
		
		System.out.println("O valor original da 1º após a divisão: " +  var1);
		System.out.println("O valor original da 2º após a divisão: " +  var2);
		
	}

}
