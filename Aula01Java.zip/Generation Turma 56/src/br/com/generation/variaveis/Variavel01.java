package br.com.generation.variaveis;

public class Variavel01 {

	public static void main(String[] args) {
		int numero;
		
		int idade = 10;
		System.out.println("Idade: ");
		
		
	}

}
