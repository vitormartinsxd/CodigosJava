package br.com.generation.variaveis;

import java.util.Scanner;
public class Variaveis02 {
		// OperadoresAritméticos

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		int x, y;
		int resultado;
		
		
		System.out.println("Digite o numero de x:");
		x = entrada.nextInt();
		System.out.println("Digite o numero de y:");
		y = entrada.nextInt();
		
		resultado = x + y;
		System.out.println("A somo é: " + resultado);
		
		resultado = x - y;
		System.out.println("A subtração é: " + resultado);
		
		resultado = x * y;
		System.out.println("A multiplação é: " + resultado);
		
		resultado = x / y;
		System.out.println("A divisão é: " + resultado);
		
		resultado = x % y;
		System.out.println("O modulo é: " + resultado);
		
		

	}

}
