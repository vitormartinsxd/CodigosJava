package br.com.generation.aula02;
import java.util.Scanner;

public class GalaoLitro {

	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		double galoes, litros;
		
		System.out.println("Digite a quantidade de galões: ");
		galoes = entrada.nextDouble();
		System.out.println("Digite a quantidade de litros: ");
		litros = entrada.nextInt();
		
		litros = galoes * 3.600;
		System.out.println(galoes + " galões são " + litros + " litros americanos");
		
		galoes = litros/3.600;
		System.out.println(litros + " litros são " + galoes + " galoes");
	}

}
