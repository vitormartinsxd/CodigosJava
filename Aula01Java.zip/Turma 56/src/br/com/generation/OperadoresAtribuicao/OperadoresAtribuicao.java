package br.com.generation.OperadoresAtribuicao;

public class OperadoresAtribuicao {

	public static void main(String[] args) {
		int x = 10;
		
		System.out.println(x);

		x += 25;
		System.out.println(x);

		x /= 2;
		System.out.println(x);

		x %= 2;
		System.out.println(x);
		
	}

}
